import React, { useContext } from 'react'
import Sidebar from "../sidebar/Sidebar"
import Player from '../player/Player'
import Display from '../display/Display'
import { PlayerContext } from '../playercontext/PlayerContext'



const Layout = () => {

  const {audioRef,track} = useContext(PlayerContext)


  return (
    <div className="h-screen bg-black " >
    <div className="h-[90%] flex">
     <Sidebar/>
    
     <Display/>
 
    </div>
    <div >
        <Player/>
    </div>
    <audio  ref={audioRef} src={track.file} preload='auto'></audio>
     

   </div>
  
 


  )
}

export default Layout